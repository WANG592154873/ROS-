#include "includes.h"

void Bsp_Configuration(void)
{
}
