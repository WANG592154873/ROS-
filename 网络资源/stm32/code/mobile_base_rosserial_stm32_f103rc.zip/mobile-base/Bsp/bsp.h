#ifndef __BSP_H__
#define __BSP_H__

#include <stdint.h>

void Bsp_Configuration(void);

#endif
