
/*********************************************
STM32F103 ����ͨ�� ģ���ƶ�����
��ȡcmd_vel��Ϣ ����odom��Ϣ

Debug Port:
					PA9   USART1_TX    
					PA10  USART1_RX
Communication Port:
					PB10	USART3_TX
					PB11	USART3_RX
@StevenShi
*********************************************/
/* Includes ------------------------------------------------------------------*/
//#include "delay.h"
//#include "debug_x.h"
#include "com_x.h"
#include "includes.h"
#include "std_msgs/String.h"

/**********************************************************************************************************************/

void msgCallBack(const std_msgs::String& msg);
std_msgs::String msg1;

//-------------ROS����----------------
ros::NodeHandle nh;
ros::Subscriber<std_msgs::String> sub("stm_subscribe", msgCallBack);
ros::Publisher pub("stm_publish",&msg1);
int i=0;


void msgCallBack(const std_msgs::String& msg)
{   
    char hello[13];
    sprintf(hello, "%d", i++);    
    msg1.data = hello;
    pub.publish(&msg1);
    i++;
}

int main(void)
{
	
	/*
	delay_init(); 
	
	com_x_usart_Init();
	
	debug_x_usart_Init();
	
	delay_ms(1000);
	
	printf("\n\r--------------mobilebase����---------------------\n ");
	
	while (1)
	{
		
		printf("\n\r--------------���ݷ���---------------------\n ");
		
		data_pack();
		
		delay_ms(1000);
		
	}
	*/
	
	    // ��ʼ���׶�
    System_Init();
    delay_ms(1000);
    Bsp_Configuration();
    App_Init();
    // ��ʽ����ros����
	nh.initNode();
	nh.advertise(pub);
    nh.subscribe(sub);
    char hello[13] = "hello world!";
    while(1)
    {
        // msg.data = hello;
        // pub.publish(&msg);
        nh.spinOnce();
        delay_ms(10);
    }
}





#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
		/* User can add his own implementation to report the file name and line number,
			 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

		/* Infinite loop */
		while (1)
		{}
}

#endif

/**
  * @}
  */ 



